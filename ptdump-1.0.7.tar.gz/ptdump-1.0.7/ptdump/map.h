void *mapfile(char *fn, size_t *size);
void unmapfile(void *map, size_t size);
